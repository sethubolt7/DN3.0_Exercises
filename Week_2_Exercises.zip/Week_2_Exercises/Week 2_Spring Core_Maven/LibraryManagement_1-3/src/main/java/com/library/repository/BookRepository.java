package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

    public void repository(){
        System.out.println("Repository is called!!");
    }
}
